A.D — Audit frontend
Branche : codex/ad-rebuild
Commit : b04a5fd0bdd3a6c2d32a143be1080372ba0072c0

source/ : code source suivi par Git, tests, lockfile et scripts.
review/ : prévisualisation HTML autonome et captures réelles Chromium.

Validation exécutée : 16 tests métier, 19 tests navigateur, TypeScript et build réussis.
Les captures peuplées utilisent des données synthétiques de QA isolées.
Aucun export source Sites V66, donnée historique ou backend connecté.
Aucun secret, dossier node_modules ou métadonnée Git inclus.
La prévisualisation a été vérifiée via HTTP local ; ouverture file:// non vérifiée en raison de la politique du navigateur cloud.

Reproduire dans source/ : npm ci ; npm test ; npm run typecheck ; npm run build ; npm run test:e2e
Les tests navigateur nécessitent Chromium (/usr/bin/chromium ou CHROMIUM_PATH).
